
import github from "../assets/img/contact/github.gif";
import facebook from "../assets/img/contact/facebook.gif";
import discord from "../assets/img/contact/discord.gif";
import linkedin from "../assets/img/contact/linkedin.gif";
import hi from "../assets/img/contact/hithere.svg";
import donate from "../assets/img/contact/donate.png";
import "../assets/AboutPage.scss";

const ContactPage = () => {
  return (
    <div className="container">
      <h1 className="center">
        <img src={hi} />
        &nbsp;
      </h1>
      <br />
      <div className="infor">
        <div className="about">
          <h1>Introduction about myself</h1>
          <ul>
            <li>
              🔭 I&apos;m currently learning{" "}
              <strong>Java, ReactJS, HTML, Javascript, CSS</strong>
            </li>
            <li>❤️ I&apos;m passionate about:</li>
            <ul>
              <li>🪐 Universe</li>
              <li>🖥️ Front-end Developer</li>
            </ul>
          </ul>
          <br />
          <br />
        </div>

        {/* <img
          className="mario-gif"
          align="right"
          alt="Coding"
          width="550"
          height="350"
          src={mario}
        ></img> */}
      </div>
      <h1>
        
        Connect with me{" "}
      </h1>
      <br />
      <div className="gif-contact">
        <a href="https://github.com/kotkala" target="_blank" rel="noreferrer">
          <img src={github} alt="github" />
        </a>
        <a
          href="https://www.facebook.com/klong.tram/"
          target="_blank"
          rel="noreferrer"
        >
          <img src={facebook} alt="facebook" />
        </a>
        <a
          href=""
          target="_blank"
          rel="noreferrer"
        >
          <img src={linkedin} alt="linkedin" />
        </a>
        <a href="" target="_blank" rel="noreferrer">
          <img src={discord} alt="discord" />
        </a>
      </div>
      <div className="donate">
        <a href="https://ko-fi.com/kotkala" target="_blank" rel="noreferrer">
          <img
          className="donateImage"
            align="left"
            src={donate}
            height="50"
            width="210"
            alt="baka"
          />
        </a>
      </div>
    </div>
  );
};

export default ContactPage;
