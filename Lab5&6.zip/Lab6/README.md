# Lab 6

## Documents
- Document: [Click here!!!](Lab6_About_Redux_Redux_Thunk_Redux_Toolkit.docx.pdf)

## Build
### Install dependencies:
```bash
npm install
```
### Run:
```bash
npm run dev
```