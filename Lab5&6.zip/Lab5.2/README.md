# Lab 5.2

## Documents

- Document: [Click here!!!](Lab5_About_React_Router.docx.pdf)

## Build

### Install dependencies:

```bash
npm i
```

### Run:

```bash
npm run dev
```
