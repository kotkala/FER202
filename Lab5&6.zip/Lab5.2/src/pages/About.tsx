import NavbarComponent from "../components/NavbarComponent";

const About = () => {
  return (
    <>
      <NavbarComponent />
      <>
        <iframe
          style={{ height: "900px", width: "100%", justifyContent: "center" }}
          src=""
        ></iframe>
      </>
    </>
  );
};

export default About;